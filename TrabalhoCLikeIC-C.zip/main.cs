using System;

class Program {
  public static void Main (string[] args) 
  {
    Console.Write("Digite a quantidade de vencedores do sorteio: ");
    int qtdVencedores = int.Parse(Console.ReadLine());
    if (qtdVencedores <= 10)
    {
      int [] vetTamanho = new int [qtdVencedores];
      Random r = new Random ();
      int contVenceTam1 = 0, contVenceTam2 = 0;
      for (int i = 0; i < qtdVencedores; i++)
      {    
        Console.WriteLine($"Digite o tamanho da camisa do vencedor nº " + (i+1) + ":");
        vetTamanho[i] = int.Parse(Console.ReadLine());
        if (vetTamanho[i] == 1 || vetTamanho[i] == 2)
        {          
          if (vetTamanho[i] == 1){
            contVenceTam1++;
          }
          if (vetTamanho[i] == 2){
            contVenceTam2++;
          }
        }
        else 
        {
          Console.WriteLine("Tamanho inválido!");
        }        
      }
      int qtdCamisa1 = r.Next(1,6), qtdCamisa2 = r.Next(1,6);
      Console.WriteLine("Quantidade de camisas do tamanho 1: " + qtdCamisa1);
      Console.WriteLine("Quantidade de camisas do tamanho 2: " + qtdCamisa2);
      if (contVenceTam1  >= qtdCamisa1 && contVenceTam2 >= qtdCamisa2)
      {
        Console.WriteLine("S");
      }
      else 
      {
        Console.WriteLine("N");      
      }
    }
    else 
    {
      Console.WriteLine("O número máximo de vencedores é 10!");
    }
  }
}